public class Mammal {
    //every mammall 'has' energy level of 300
    protected int energyLevel = 300; //use protected as Bat class will inherit Mammal class

    public int displayEnergy() {
        System.out.println("Energy:" + this.energyLevel); //energyLevel from this instance
        return this.energyLevel;
    }

    public Mammal(int energyLevel) {
        this.energyLevel = energyLevel;
    }
}