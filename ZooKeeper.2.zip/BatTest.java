public class BatTest {
    public static void main(String[] args) {
        //instantiate a bat
        Bat bat = new Bat(300); //*must include argument to fulfill inheritance from "energyLevel" from Mammall class

        bat.eatHuman(); // should print method's return statement and decrease energyLevel
        bat.attackTown(); //"^"
        bat.fly(); //"^"
    }
}