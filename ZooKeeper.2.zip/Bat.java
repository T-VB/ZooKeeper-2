public class Bat extends Mammal{ //use extend to inherit from Mammal class
    //add 'super(method)' to constructor
    public Bat(int energyLevel) {
        super(energyLevel); //Bat now inherits energyLevel from Mammal class
    }

    public void eatHuman() {
        this.energyLevel += 25;
        System.out.println("Hey, that bat just killed Kenny!");
    }

    public void attackTown() {
        this.energyLevel -= 100;
        System.out.println("the town is being attacked!");
    }

    public void fly() {
        this.energyLevel -= 50;
        System.out.println("eeeeek! a huge bat in the sky!");
    }
}